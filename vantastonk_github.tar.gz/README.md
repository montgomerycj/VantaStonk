# VantaStonk v2

Autonomous AI trading assistant built on the 95v2 strategy with real-time price monitoring and Telegram integration.

## Features

- **95v2 Strategy Framework**: Momentum, Pair Trades, Macro Tilt, Defensive Hedges, ShadowList tracking
- **Real-time Price Monitoring**: 10-minute scans with threshold-based alerts
- **Telegram Integration**: Two-way communication via webhook
- **Persistent Memory**: Watchlist, positions, and trading history
- **Rate Limiting**: Built-in guardrails (20 messages per 10 minutes)
- **Duplicate Prevention**: Avoids suggesting already-owned or tracked tickers

## Quick Start

1. Install dependencies: `pip install -r requirements.txt`
2. Configure Telegram bot token and chat ID in `main.py`
3. Run: `python main.py`

## Commands

- `help` - Show all commands
- `status` - Agent health and stats
- `show my stonks` - Display positions
- `show watchlist` - Show monitored tickers
- `add TICKER to watchlist` - Add ticker for monitoring
- `set TICKER threshold at X` - Set X% alert threshold
- `show shadowlist` - Show AI quant fund tracking
- `test price TICKER` - Get real-time price

## Architecture

- **Flask backend** with webhook endpoints
- **Yahoo Finance API** for real-time data
- **ChatGPT integration** for 95v2 analysis
- **JSON file storage** for persistence

## Deployment

Designed for permanent deployment with 24/7 autonomous operation.

---

*Built with Manus AI development platform*

